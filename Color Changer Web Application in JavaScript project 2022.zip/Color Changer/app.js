/**
 * Project Requirements:
 * - Change the background color by generating random rbg color by clicking a button
 */

// Steps

// Globals
let div = null;

// Step 1 - create onload handler
window.onload = () => {
	main();
};

function main() {
	const root = document.getElementById('root');
	const btn = document.getElementById('colorBtn');
	const output = document.getElementById('output');
	const output2 = document.getElementById('output2');
	const copyBtn1 = document.getElementById('copyBtn1');
	const copyBtn2 = document.getElementById('copyBtn2');

	// RGB Color function call Code Start
	btn.addEventListener('click', function () {
		const bgColor = generateRGBColor();
		root.style.backgroundColor = bgColor;
		output.value = bgColor;
	});
	// RGB Color function call Code End
	
	// RGB Color Copy Button Code Start
	copyBtn1.addEventListener('click', function () {
		navigator.clipboard.writeText(output.value);
		alert("RGB Color Code Copy Success");
	});
	// RGB Color Copy Button Code End
	
	// Hex Color function call Code Start
	btn.addEventListener('click', function () {
		const bgColor = generateHexColor();
		root.style.backgroundColor = bgColor;
		output2.value = bgColor;
	});
	// Hex Color function call Code End
	
	// Hex Color Copy Button Code Start
	copyBtn2.addEventListener('click', function () {
		navigator.clipboard.writeText(output2.value);
		alert("Hex Color Code Copy Success");
	});
	// Hex Color Copy Button Code End
}

// random RGB color generator function
function generateRGBColor() {
	// rgb(0, 0, 0), rgb(255, 255, 255)
	const red = Math.floor(Math.random() * 256);
	const green = Math.floor(Math.random() * 256);
	const blue = Math.floor(Math.random() * 256);

	return `rgb(${red}, ${green}, ${blue})`;
}

// random Hex color generator function
function generateHexColor() {
	// #000000 #ffffff
	// 255, 255, 255 -> #FFFFFF
	const red = Math.floor(Math.random() * 256);
	const green = Math.floor(Math.random() * 256);
	const blue = Math.floor(Math.random() * 256);

	return `#${red.toString(16)}${green.toString(16)}${blue.toString(16)}`;
}

//